#!/sbin/sh
echo 本包完全免费请勿倒卖 作者@py9639
echo 本刷机包为小米9（cepheus）刷写Windows
echo 本次刷写将清除数据，请注意备份，五秒后继续
sleep 5
echo 请先下载Windows包到/sdcard下并命名为win.wim，https://www.123912.com/s/lGrLjv-hgFk
#将下方$space替换为Windows c盘空间，注意不要带单位默认为GB，输入数字即可
partition $space 
win=$(sgdisk --print /dev/block/sda | awk 'NR>9 && $1 ~ /^[0-9]+$/ {last=$1} END {print last}')
esp=$(sgdisk --print /dev/block/sda | awk 'NR>9 && $1 ~ /^[0-9]+$/ {second_last=last; last=$1} END {print second_last}')

mkdir /mnt/esp
mount /dev/block/sda$esp /mnt/esp
./ntfs-3g /dev/block/sda$win /mnt/win
echo 时间约5-10分钟请耐心等待
./wimlib-imagex apply /sdcard/win.wim 2 /mnt/win     --no-acls     --no-attributes
cp /mnt/win/Windows/Boot/EFI/Microsoft/Boot/* /mnt/esp/EFI/Microsoft/Boot
cp BCD  /mnt/esp/EFI/Microsoft/Boot
./bcdboot /mnt/esp/EFI/Microsoft/Boot/BCD /dev/block/sda$win
echo 是否需要现在重启到Windows
echo ［y/n］
read reboot
if ["$reboot" == y];then
    dd if=uefi.img of=/dev/block/by-name/boot
elif ["$reboot" == n]
    cp uefi.img /sdcard
    echo 进入安卓后请自行刷入/sdcard/uefi.img到boot进入
    reboot
else
    reboot